import discord
from discord.ext import commands
import json
import requests
import google.generativeai as genai  # Gemini用
import datetime  # 稼働時間用

# 設定の読み込み
with open("config.json", "r", encoding="utf-8") as f:
    config = json.load(f)

# Intents の設定
intents = discord.Intents.default()
intents.message_content = True

# Bot の初期化
bot = commands.Bot(command_prefix="!", intents=intents)
start_time = datetime.datetime.now()
# Gemini APIキー設定
gemini_api_key = config.get("gemini_api_key")
if gemini_api_key:
    genai.configure(api_key=gemini_api_key)
    gemini_model = genai.GenerativeModel("models/gemini-2.5-flash")  # ← モデル名を変更
else:
    gemini_model = None

# 起動時のログ表示
@bot.event
async def on_ready():
    print(f"✅ Botがログインしました: {bot.user.name} ({bot.user.id})")

# 天気情報取得コマンド
@bot.command(name="weather")
async def weather(ctx, *, city: str):
    key = config.get("weather_api_key")
    if not key:
        return await ctx.send("⚠️ APIキーが設定されていません。")

    url = (
        f"http://api.openweathermap.org/data/2.5/weather"
        f"?q={city}&appid={key}&units=metric&lang=ja"
    )

    try:
        res = requests.get(url, timeout=5).json()
    except requests.exceptions.RequestException as e:
        return await ctx.send(f"⚠️ APIリクエストに失敗しました: {e}")

    if res.get("cod") != 200:
        return await ctx.send(
            f"⚠️ 天気情報を取得できませんでした: {res.get('message', '不明なエラー')}"
        )

    weather_desc = res["weather"][0]["description"]
    temp = res["main"]["temp"]
    humidity = res["main"]["humidity"]

    embed = discord.Embed(
        title=f"{city} の天気 🌤️",
        color=discord.Color.blue()
    )
    embed.add_field(name="天気", value=weather_desc, inline=True)
    embed.add_field(name="気温", value=f"{temp} °C", inline=True)
    embed.add_field(name="湿度", value=f"{humidity}%", inline=True)
    embed.set_footer(text="Powered by OpenWeatherMap")

    await ctx.send(embed=embed)

# Gemini応答コマンド
@bot.command(name="gemini")
async def gemini(ctx, *, prompt: str):
    if not gemini_model:
        return await ctx.send("⚠️ Gemini APIキーが設定されていません。")

    loading_msg = await ctx.send("🤖 回答を生成しております...")

    try:
        response = gemini_model.generate_content(prompt)
        await loading_msg.edit(content=response.text)
    except Exception as e:
        await loading_msg.edit(content="⚠️ Gemini APIの呼び出し中にエラーが発生しました。")
        print(f"Gemini API エラー: {e}")

# サーバー情報表示コマンド
@bot.command(name="server")
async def server_info(ctx):
    now = datetime.datetime.now()
    uptime = now - start_time
    hours, remainder = divmod(int(uptime.total_seconds()), 3600)
    minutes, seconds = divmod(remainder, 60)

    gemini_version = gemini_model.model_name if gemini_model else "未設定"

    embed = discord.Embed(
        title="🖥️ サーバー情報",
        color=discord.Color.green()
    )
    embed.add_field(name="サーバー機種", value="Lenovo G570", inline=False)
    embed.add_field(name="CPU", value="Intel Core i5-2450M", inline=False)
    embed.add_field(name="RAM", value="8GB", inline=False)
    embed.add_field(name="HDD", value="1TB", inline=False)
    embed.add_field(name="OS", value="Ubuntu 24.04.2 LTS", inline=False)
    embed.add_field(name="稼働時間", value=f"{hours}時間 {minutes}分 {seconds}秒", inline=False)
    embed.add_field(name="Geminiモデル", value=gemini_version, inline=False)
    embed.set_footer(text="自宅サーバー構成 + Botステータス")

    await ctx.send(embed=embed)


# ヘルプ表示
@bot.command(name="bothelp")
async def bot_help(ctx):
    embed = discord.Embed(
        title="📘 Botコマンド一覧と使い方",
        description="以下は現在利用可能なコマンドです。",
        color=discord.Color.teal()
    )

    embed.add_field(
        name="`!weather <都市名>`",
        value=(
            "指定した都市の天気情報を表示します。\n"
            "🌍 **都市名は英字で入力してください。**（例：`tokyo`, `osaka`, `new york`）\n"
            "例：`!weather tokyo`"
        ),
        inline=False
    )
    embed.add_field(
        name="`!gemini <質問やメッセージ>`",
        value=(
            "Gemini AI に質問やメッセージを送信して応答を得ます。\n"
            "例：`!gemini Pythonのfor文について教えて`"
        ),
        inline=False
    )
    embed.add_field(
        name="`!server`",
        value="サーバー構成、稼働時間、Geminiモデル情報を表示します。",
        inline=False
    )

    embed.add_field(
        name="📝 Gemini利用時のご注意",
        value=(
            "・**短時間に連続して送信しないでください。**\n"
            "　→ 応答が遅くなったり、停止する可能性があります。\n"
            "・**非常に長い文章や複雑な内容は避けてください。**\n"
            "　→ 処理が重くなり、正しく応答できない場合があります。\n\n"
            "快適にご利用いただくため、適度な間隔と簡潔な入力をおすすめします。"
        ),
        inline=False
    )

    embed.set_footer(text="Botの使い方ガイド")

    await ctx.send(embed=embed)

# Bot 起動
if __name__ == "__main__":
    token = config.get("token")
    if not token:
        print("❌ config.json に Botトークンが設定されていません。")
    else:
        bot.run(token)

